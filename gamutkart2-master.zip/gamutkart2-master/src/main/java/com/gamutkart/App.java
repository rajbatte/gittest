package com.gamutkart;

public class App 
{
    public static void main( String[] args )
    {
		int i;
		for(i=0;i<=400;i++)
		{
			i += 3;
        	System.out.println( "print number: " + i);
        	System.out.println( "print number: " + i);
   		}
	 }
}
